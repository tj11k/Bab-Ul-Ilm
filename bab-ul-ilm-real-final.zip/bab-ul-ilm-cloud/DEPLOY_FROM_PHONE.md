# Bab UL Ilm — phone-only deployment

## A. Upload the ZIP to GitHub
1. Create a GitHub repository (private is recommended).
2. Extract this ZIP before uploading, so `package.json`, `apps/`, `db/`, and `.github/` are at the repository root.
3. Commit the files.

## B. Build the Android APK
1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Bab UL Ilm - Build Android APK**.
4. Tap **Run workflow**.
5. In `Production API URL`, enter your live API URL, for example `https://api.yourdomain.com`.
6. Run the workflow and wait for it to finish.
7. Open the completed workflow run → **Artifacts** → `bab-ul-ilm-debug-apk` → download the ZIP and extract the APK.

## C. Important
The APK build is automated, but the app still needs a live backend/database for real shared data. The repository includes the API and PostgreSQL schema. External providers such as UPI/Razorpay, WhatsApp, SMS, email, object storage, and Google Play signing require the institution's own provider credentials and production configuration.

## D. Production Android release
The included workflow creates a **debug APK** for direct testing. A Play Store release should use a signed AAB with a private keystore stored in GitHub Actions secrets. Do not commit a keystore or production secrets to the repository.
