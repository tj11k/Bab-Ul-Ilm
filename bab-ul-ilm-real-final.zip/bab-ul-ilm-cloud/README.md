# Bab UL Ilm — Real Mobile + Web Cloud System

Institution: **Madarsa Ahle Sunnat Bab UL Ilm Raza E Mustafa**

This repository is the deployable full-stack foundation for a shared Web + Android management system. Both clients use the same HTTP API and PostgreSQL database.

## What is functional

- PostgreSQL schema + migration/seed
- Secure login with bcrypt password hashes + JWT
- Role checks in API (Super Admin override)
- Audit log for created/upserted records
- Students/admissions CRUD
- Branches CRUD
- Classes, subjects, exams CRUD
- Attendance by date with present/absent/leave
- Marks API
- Hostel rooms and resident allocations API
- Fees and accounting transactions CRUD
- HR/employees CRUD
- Library books CRUD
- Inventory CRUD
- Notices CRUD
- Central settings/branding store
- Responsive web dashboard
- English + Urdu RTL switch
- Dark/light theme
- Android APK build through GitHub Actions using Capacitor

## Default account

Email: `admin@babulilm.local`
Password: `ChangeMe123!`

Change this immediately after first deployment. For a public production deployment, also set a long random `JWT_SECRET` and a managed PostgreSQL database.

## Phone-only deployment path

1. Create a GitHub repository.
2. Extract this ZIP and upload the **contents** to the repository root.
3. Make sure `.github/workflows/build-apk.yml` exists.
4. Deploy `apps/api` to a Node 20/22 capable host and attach PostgreSQL. Run `npm install`, then `npm run db:migrate --workspace apps/api`, then `npm run start --workspace apps/api`.
5. Deploy `apps/web` to a static host with `VITE_API_URL=https://YOUR-API-DOMAIN`.
6. GitHub → Actions → **Bab UL Ilm - Build APK** → Run workflow → enter the same API URL.
7. Download the `bab-ul-ilm-apk` artifact.

The APK is a native Android Capacitor shell around the same web application, so web and app share the same API/data.

## Production requirements

A real online deployment still needs external infrastructure/accounts: PostgreSQL hosting, API hosting, web hosting, HTTPS domain, and optional provider credentials for SMS, WhatsApp, email, push notifications and online payments. Those cannot be embedded into source code safely.
