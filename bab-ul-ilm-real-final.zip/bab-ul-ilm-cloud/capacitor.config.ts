import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig={appId:'com.babulilm.management',appName:'Bab UL Ilm',webDir:'apps/web/dist',server:{androidScheme:'https'}};
export default config;
