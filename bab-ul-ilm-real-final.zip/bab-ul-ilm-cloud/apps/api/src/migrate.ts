import 'dotenv/config'; import {Pool} from 'pg'; import fs from 'node:fs'; import path from 'node:path';
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const dir=path.resolve(process.cwd(),'../../db');
for(const f of ['schema.sql','seed.sql']){await pool.query(fs.readFileSync(path.join(dir,f),'utf8'));}
await pool.end(); console.log('Database ready');
