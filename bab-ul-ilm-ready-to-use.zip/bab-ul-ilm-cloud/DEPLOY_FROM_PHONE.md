# Phone-only APK build

You do not need Android Studio or a local PC.

1. Create/open a GitHub repository.
2. Upload the project files.
3. Make sure `.github/workflows/build-apk.yml` is present.
4. GitHub → Actions → **Bab UL Ilm - Ready APK** → **Run workflow**.
5. Download `bab-ul-ilm-ready-apk` from the completed run.
6. Extract the artifact ZIP and install `app-debug.apk`.
