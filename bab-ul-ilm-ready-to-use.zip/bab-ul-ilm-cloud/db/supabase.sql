-- Bab UL Ilm ready-to-use Supabase schema.
-- This matches the Android/web client in this repository.
create extension if not exists pgcrypto;

create table if not exists public.profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'student',
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.branches(id uuid primary key default gen_random_uuid(),name text not null,address text,active boolean default true,created_at timestamptz default now());
create table if not exists public.students(id uuid primary key default gen_random_uuid(),admission_no text unique not null,full_name text not null,father_name text,date_of_birth date,gender text,phone text,address text,class_id uuid,status text default 'active',created_at timestamptz default now());
create table if not exists public.attendance(id uuid primary key default gen_random_uuid(),student_id uuid not null references public.students(id) on delete cascade,class_id uuid,attendance_date date not null,status text not null check(status in ('present','absent','leave')),marked_by uuid,remark text,created_at timestamptz default now(),unique(student_id,attendance_date));
create table if not exists public.fees(id uuid primary key default gen_random_uuid(),student_id uuid references public.students(id) on delete cascade,fee_type text default 'General',amount numeric(12,2) not null,paid numeric(12,2) default 0,due_date date,status text default 'pending',created_at timestamptz default now());
create table if not exists public.transactions(id uuid primary key default gen_random_uuid(),type text not null check(type in ('income','expense')),category text not null,amount numeric(14,2) not null,note text,transaction_date date default current_date,branch_id uuid references public.branches(id),created_at timestamptz default now());
create table if not exists public.classes(id uuid primary key default gen_random_uuid(),name text not null,section text,academic_year_id uuid,class_teacher_id uuid,room text,created_at timestamptz default now());
create table if not exists public.subjects(id uuid primary key default gen_random_uuid(),name text not null,code text,description text,created_at timestamptz default now());
create table if not exists public.exams(id uuid primary key default gen_random_uuid(),name text not null,exam_date date,academic_year_id uuid,class_id uuid,total_marks numeric,published boolean default false,created_at timestamptz default now());
create table if not exists public.marks(id uuid primary key default gen_random_uuid(),exam_id uuid references public.exams(id) on delete cascade,student_id uuid references public.students(id) on delete cascade,subject_id uuid references public.subjects(id),marks numeric(8,2),max_marks numeric(8,2),grade text,created_at timestamptz default now(),unique(exam_id,student_id,subject_id),check(marks >= 0 and max_marks > 0 and marks <= max_marks));
create table if not exists public.hostel_rooms(id uuid primary key default gen_random_uuid(),room_no text unique not null,capacity int not null default 4,warden text,status text default 'active',created_at timestamptz default now());
create table if not exists public.hostel_allocations(id uuid primary key default gen_random_uuid(),student_id uuid references public.students(id) on delete cascade,room_id uuid references public.hostel_rooms(id),bed_no text,from_date date default current_date,to_date date,active boolean default true,created_at timestamptz default now());
create table if not exists public.employees(id uuid primary key default gen_random_uuid(),name text not null,role text not null,phone text,email text,salary numeric(12,2) default 0,join_date date,status text default 'active',branch_id uuid references public.branches(id),created_at timestamptz default now());
create table if not exists public.books(id uuid primary key default gen_random_uuid(),isbn text,name text not null,author text,category text,quantity int default 1,available int default 1,created_at timestamptz default now());
create table if not exists public.inventory_items(id uuid primary key default gen_random_uuid(),name text not null,category text,sku text unique,quantity numeric(12,2) default 0,unit text default 'pcs',reorder_level numeric(12,2) default 0,created_at timestamptz default now());
create table if not exists public.notices(id uuid primary key default gen_random_uuid(),title text not null,body text not null,audience text default 'all',published boolean default false,publish_at timestamptz,expires_at timestamptz,created_by uuid,created_at timestamptz default now());
create table if not exists public.settings(key text primary key,value jsonb not null);
insert into public.branches(name,address) select 'Main Branch','' where not exists(select 1 from public.branches);
insert into public.settings(key,value) values('branding','{"name":"Bab UL Ilm","institution":"Madarsa Ahle Sunnat Bab UL Ilm Raza E Mustafa","languages":["en","ur"],"theme":"system"}') on conflict(key) do nothing;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare new_role text;
begin
  select case when count(*)=0 then 'admin' else 'student' end into new_role from public.profiles;
  insert into public.profiles(id,full_name,role,active) values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),new_role,true);
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_admin() returns boolean language sql stable security invoker set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and active=true) $$;
create or replace function public.can_manage() returns boolean language sql stable security invoker set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and active=true and role in ('admin','staff','teacher','accountant','hr','warden','librarian','storekeeper')) $$;

alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.fees enable row level security;
alter table public.transactions enable row level security;
alter table public.classes enable row level security;
alter table public.subjects enable row level security;
alter table public.exams enable row level security;
alter table public.marks enable row level security;
alter table public.hostel_rooms enable row level security;
alter table public.hostel_allocations enable row level security;
alter table public.employees enable row level security;
alter table public.books enable row level security;
alter table public.inventory_items enable row level security;
alter table public.notices enable row level security;
alter table public.settings enable row level security;

drop policy if exists profile_self_or_admin on public.profiles;
create policy profile_self_or_admin on public.profiles for select to authenticated using(id=auth.uid() or is_admin());
drop policy if exists profile_admin_update on public.profiles;
create policy profile_admin_update on public.profiles for update to authenticated using(is_admin()) with check(is_admin());

do $$ declare t text; begin
for t in select unnest(array['branches','students','attendance','fees','transactions','classes','subjects','exams','marks','hostel_rooms','hostel_allocations','employees','books','inventory_items','notices','settings']) loop
 execute format('create policy management_read_%1$s on public.%1$s for select to authenticated using(can_manage())',t);
 execute format('create policy management_insert_%1$s on public.%1$s for insert to authenticated with check(can_manage())',t);
 execute format('create policy management_update_%1$s on public.%1$s for update to authenticated using(can_manage()) with check(can_manage())',t);
 execute format('create policy admin_delete_%1$s on public.%1$s for delete to authenticated using(is_admin())',t);
end loop; end $$;

revoke execute on function public.handle_new_user() from public,anon,authenticated;
-- Supabase Auth invokes this trigger function internally.
