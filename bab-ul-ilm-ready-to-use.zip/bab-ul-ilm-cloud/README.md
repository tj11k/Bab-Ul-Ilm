# Bab UL Ilm — Ready-to-Use Madarsa Management App

This version uses Supabase for authentication, cloud PostgreSQL data and Row Level Security. The Android APK is built by GitHub Actions.

## One-time use

1. Put the contents of this folder in a GitHub repository.
2. Open **Actions → Bab UL Ilm - Ready APK → Run workflow**.
3. Wait for the workflow to finish.
4. Open the workflow run and download the **bab-ul-ilm-ready-apk** artifact.
5. Install the APK on Android.
6. On first launch tap **Create the first admin account**. The first registered account becomes Admin automatically.

No API server, Render deployment, JWT secret or database password is required for this APK.

## Cloud database

The supplied workflow is already configured for the connected Bab UL Ilm Supabase project. Its database schema and RLS have been prepared separately. The publishable key is safe for a client application; never put a service-role/secret key in this repository.

## Important

- This workflow produces a **debug APK** for direct Android installation/testing.
- A Play Store release requires a separate signed AAB/keystore workflow.
- If Supabase email confirmation is enabled, verify the signup email before signing in.
