import type { CapacitorConfig } from '@capacitor/cli';
const config:CapacitorConfig={appId:'com.babulilm.management',appName:'Bab UL Ilm',webDir:'apps/web/dist',android:{allowMixedContent:false},server:{androidScheme:'https'}};
export default config;
